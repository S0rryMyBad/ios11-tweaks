window.addEventListener("load", function() {
    document.body.style.width='100%';
    document.body.style.height='100%';
}, false);

function notif(){
    if (groovyAPI.isShowingNotifications()){
        $('#date').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#month').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#weekday').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#hour').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#minute').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#minutesunit').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
    } else {
        $('#date').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#month').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#weekday').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#hour').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#minute').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#minutesunit').animate({'margin-top': OriginalPos + "%",}, 500);
    }

    setTimeout(notif, 1000);
};

notif();
