window.addEventListener("load", function() {
    document.body.style.width='100%';
    document.body.style.height='100%';
}, false);

function notif(){
    if (groovyAPI.isShowingNotifications()){
        $('#L1').animate({opacity:'0'}, 500);
        $('#L2').animate({opacity:'0'}, 500);
        $('#L3').animate({opacity:'0'}, 500);
        $('#L4').animate({opacity:'0'}, 500);
        $('#anchor').animate({opacity:'0'}, 500);
        $('#Cal').animate({opacity:'0'}, 500);
        $('#weekday').animate({opacity:'0'}, 500);
        $('#ampm').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#Clock').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#dots').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#Weather').animate({opacity:'0'}, 500);
    } else {
        $('#L1').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#L1').animate({opacity:'1'}, 500);
        $('#L2').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#L2').animate({opacity:'1'}, 500);
        $('#L3').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#L3').animate({opacity:'1'}, 500);
        $('#L4').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#L4').animate({opacity:'1'}, 500);
        $('#anchor').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#anchor').animate({opacity:'1'}, 500);
        $('#Cal').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#Cal').animate({opacity:'1'}, 500);
        $('#weekday').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#weekday').animate({opacity:'1'}, 500);
        $('#ampm').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#dots').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#Clock').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#Weather').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#Weather').animate({opacity:'1'}, 500);
    }

    setTimeout(notif, 1000);
};

notif();
