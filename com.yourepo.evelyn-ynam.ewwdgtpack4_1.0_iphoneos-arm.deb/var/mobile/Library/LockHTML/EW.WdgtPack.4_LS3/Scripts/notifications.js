window.addEventListener("load", function() { 
    document.body.style.width='100%';
    document.body.style.height='100%';
}, false);

function notif(){
    if (groovyAPI.isShowingNotifications()){
        $('#C1').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#C2').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#Clock').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#ampm').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
    } else {
        $('#C1').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#C2').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#Clock').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#ampm').animate({'margin-top': OriginalPos + "%",}, 500);
    }

    setTimeout(notif, 1000);      
};

notif();