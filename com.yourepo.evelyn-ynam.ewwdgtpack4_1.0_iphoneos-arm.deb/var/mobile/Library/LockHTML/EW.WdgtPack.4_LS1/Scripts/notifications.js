window.addEventListener("load", function() { 
    document.body.style.width='100%';
    document.body.style.height='100%';
}, false);

function notif(){
    if (groovyAPI.isShowingNotifications()){
        $('#weatherIcon').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#R').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#Separator').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#Cal').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#Clock').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
        $('#month').animate({'margin-top': ShiftUp_Notif + "%",}, 500);
    } else {
        $('#weatherIcon').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#R').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#Separator').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#Cal').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#Clock').animate({'margin-top': OriginalPos + "%",}, 500);
        $('#month').animate({'margin-top': OriginalPos + "%",}, 500);
    }

    setTimeout(notif, 1000);      
};

notif();