/* 
Configurations
Credits: original code by Dacal, Junesiphone & Matchstic, modified by Evelyn
*/

var Clock = "12h";	       // choose between "12h" or "24h".
var Lang = "en";	           // choose between "ca", "en", "fr" or "de".